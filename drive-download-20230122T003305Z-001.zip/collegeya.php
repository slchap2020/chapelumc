<?php include ('header.php'); ?>

<?php include ('menu.php'); ?>



<div >
<img src="collegeyapic.png" alt="addressicon" class="addicon"  style="width:100%" />
</div>

<div class="about">
<?php
echo "<h1> Our Mission</h1>";
echo "Our goal is to bring Young Adults and college students closer to Christ, and closer to one another, building intergenerational community and relationships." ;
?>


<div class="about">
<?php
echo "<h3> College Ministry</h3>";
echo "Our college ministry was created to minister to and speak into the lives of college students in the Deerfield area. During the school year, students gather at Chapel Church for worship once a week on Thursday nights and attend men’s and women’s small groups. During the summer months, students and young adults still in town meet sporadically for small groups, events, and worship nights." ;
?>
</div>

<div class="about">
<?php
echo "<h3> Young Adult MInistry</h3>";
echo "ometimes it feels like church community shies away from young adults. Sure, there’s Middle School and High School youth groups, there are college ministries (typically ages eighteen to twenty-two), but what do we do after college? Some of the most crucial years for our spiritual growth, and our community building are our “young adult” years but finding that community can be difficult. We are looking to make that community-building process simple! If you are a young adult seeking intentional community, we want to create a space, and opportunities for you to grow in your faith and your pursuit of life with people in the same season." ;
?>
</div>




<div>
<?php include ('footer.php'); ?>