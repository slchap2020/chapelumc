<?php

$conn = mysqli_connect('mysql8002.site4now.net','a8ec59_salliec','Chappell2022','db_a8ec59_salliec') or die('connection failed');

?>