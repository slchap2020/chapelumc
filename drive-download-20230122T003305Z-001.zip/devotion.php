<?php include ('header.php'); ?>

<?php include ('menu.php'); ?>



<div >
<img src="devotionpic.png" alt="addressicon" class="addicon"  style="width:100%" />
</div>

<div class="about">
<?php
echo
 "Read Mark 13: 1-27<br />

Prayer: O God, I get impatient and I want you to bring about what I want, when I want! Help me to be ready and see signs of your glory all around. May I not be anxious for the end and know that you are with us always. Amen.  <br />
<br />
Read Mark 14: 1-11 <br />

Prayer: Lord God, help me to fully experience with my heart the love that Jesus shows as he moves towards the cross willingly. I sometimes find it hard to believe someone would die for me. Thank you for your grace. Amen.  <br />
<br />
Read Mark 14: 26-52.  <br />

Prayer: Lord Jesus, I sometimes don’t fully understand the idea of your rest and crucifixion. Give me a clear understanding of what it means to lose my life in you, so I might save it for eternity. Amen.   <br />
<br />
Read Mark 15: 1-32 <br />

Prayer: O Lord, I tend to push death away, but today help me remember that death is an integral part of life and not something to be feared because of Jesus. Give me faith when fear creeps in. Amen.   <br />
<br />
Read Mark 16 <br />

Prayer: Lord Jesus, I often take Easter for granted. Help me to see you with new eyes today as I remember your resurrection and that the worst thing in my life is never the last thing. Amen.  <br />
<br />
Read Mark 3:1-6 <br />

Prayer: O God, Jesus came to show us how to love people and not be legalistic. Help me not to become so righteous that I lose sight of your Kingdom, and at the same time honor the Sabbath and keep it holy. Amen.  <br />
<br />
 " ;
?>





<div>
<?php include ('footer.php'); ?>