<?php

    $accounts = array (
        array("username" => "customer", "password" => "customer"),
        array("username" => "publisher", "password" => "publisher"),
        array("username" => "admin", "password" => "admin"),
);
?>