<?php include ('header.php'); ?>

<?php include ('menu.php'); ?>




<div class="about">
<?php
print "Phone: 804-731-5999" ;
?>
</div>

<div class="about">
<?php
print "Email: slchappell@liberty.edu" ;
?>
</div>
<div class="about">
<?php
print "Address: 1234 Nowhere Dr. Deerfield Beach, FL 81301" ;
?>
</div>

<div class="modules">


<button class= "menubutton" onclick="document.location = 'about.php'">About Us </button>
<button class= "menubutton" onclick="document.location = 'contact.php'">Contact Us</button>
<button class= "menubutton" onclick="document.location = 'hostphp.php'">Hosting PHP Configuration</button>

</div>

<div>
<?php include ('footer.php'); ?>
