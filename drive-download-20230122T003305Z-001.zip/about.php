<?php include ('header.php'); ?>

<?php include ('menu.php'); ?>

<div class="about">
<?php
echo "<h3> Mission</h3>" ;
echo "Our mission is to love God, love people, and share Jesus with the world.";
echo "\n";
?>
</div>

<div class="about">
<?php
echo "<h3> Vision</h3>" ;
echo "Be the good in the world.";
echo "\n";
?>
</div>

<div class="about">
<?php
echo "<h3> Goals</h3>" ;
echo "1. Increasing church revenues<br />

2. Increasing and retaining membership<br />

3. Teaching the Word of God<br />

4. Increasing stewardship<br />

5. Making worship services more relevant<br />

6. Establishing an effective communication system<br />

7. Maintaining and upgrading our buildings and grounds<br />

8. Improving our music ministry<br />

9. Expanding our community service<br />";
echo "\n";
?>
</div>

<div class="about">
<?php
echo "Chapel Church is a United Methodist Church in Deerfield Beach Florida. Here at Chapel our mission is to love God, love people, and share Jesus with the world. This mission enables us to live out our vision: to be the good in the world. We are a family friendly church with many opportunities to get connected with the church and to volunteer within our community. We do not want to keep our faith within these walls. We want to share Jesus with the world" ;
echo "\n";
?>
</div>

<div class="about">
<?php
echo "We would like to welcome you and your entire family to join us for worship. Our church services are on Sundays at 8:00am, 9:30am and 11:00am. We provide childcare for ages 3mos-5th grade during all of our services. Children ages 3 months to two years will be cared for in our nursery. Three-year-olds to Fifth Graders will participate in an age-appropriate lesson that aligns with the Sunday sermon. We do this so you can talk to your children about God throughout the week. We look forward to seeing you and your family at church on Sunday." ;
?>
</div>

<div class="modules">

<button class= "menubutton" onclick="document.location = 'about.php'">About Us </button>
<button class= "menubutton" onclick="document.location = 'contact.php'">Contact Us</button>
<button class= "menubutton" onclick="document.location = 'hostphp.php'">Hosting PHP Configuration</button>

</div>

<div>
<?php include ('footer.php'); ?>
