<div id="modulebuttons" class="modules">

<button class= "menubutton" onclick="document.location = 'foundations.php'">Module 1: Week 1 Foundations</button>
<button class= "menubutton" onclick="document.location = 'about.php'">About Us </button>
<button class= "menubutton" onclick="document.location = 'contact.php'">Contact Us</button>
<button class= "menubutton" onclick="document.location = 'hostphp.php'">Hosting PHP Configuration</button>

</div>

<?php phpinfo();?>


<div>
<?php include ('footer.php'); ?>
