<?php include ('header.php'); ?>

<?php include ('menu.php'); ?>



<div class="row">
    <div class="column">
        <a href= "about.php" > <img src="aboutuspic.png" alt="about" style="width:100%"/></a>
    </div>
    <div class="column">
        <a href= "contact.php" > <img src="contactuspic.png" alt="contact"  style="width:100%"/></a>
    </div>
</div>

<div class="php">
<a href= "hostphp.php" class="phpconfig">  Hosting PHP Configuration </a>
</div>

<div>
<?php include ('footer.php'); ?>
